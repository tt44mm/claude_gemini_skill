---
name: gemini-search
description: Performs AI-powered web searches using Google's Gemini API with Google Search grounding. Use when the user explicitly requests Gemini search, asks "use Gemini to search", "search with Gemini", "Gemini AI search", or wants real-time information via Gemini's grounded search capabilities. Provides responses with source citations. Requires GEMINI_API_KEY environment variable.
---

# Gemini Search Skill

AI-powered web search using Google Gemini with Google Search grounding for real-time, cited responses.

## Setup

**API Key Required:** Set the `GEMINI_API_KEY` environment variable before use:

```bash
export GEMINI_API_KEY="your-api-key-here"
```

Get your API key at: https://aistudio.google.com/apikey

**Note for EU users:** The free tier cannot serve EU users. Use the paid API tier with a billing account.

## Usage

### Basic Search

```bash
python3 scripts/gemini_search.py "What are the latest AI developments?"
```

### With Options

```bash
# JSON output with all metadata
python3 scripts/gemini_search.py "Current weather in Barcelona" --format json

# Markdown formatted response
python3 scripts/gemini_search.py "Latest tech news" --format markdown

# Use specific model
python3 scripts/gemini_search.py "Query" --model gemini-2.5-pro

# Without source citations
python3 scripts/gemini_search.py "Query" --no-sources
```

### Python Integration

```python
from scripts.gemini_search import gemini_search

result = gemini_search(
    query="What happened in the news today?",
    model="gemini-2.5-flash",
    output_format="markdown",
    include_sources=True
)

print(result['response'])
for source in result['sources']:
    print(f"- {source['title']}: {source['uri']}")
```

## Available Models

| Model | Best For |
|-------|----------|
| `gemini-2.5-flash` | Fast responses, general queries (default) |
| `gemini-2.5-pro` | Complex analysis, detailed research |
| `gemini-2.0-flash` | Legacy support |

## Output Formats

- **text**: Plain text with sources appended
- **json**: Structured JSON with response, sources, metadata
- **markdown**: Formatted markdown with headers and links

## Response Structure

```json
{
  "response": "The search result text...",
  "sources": [
    {"title": "Source Name", "uri": "https://..."}
  ],
  "metadata": {
    "model": "gemini-2.5-flash",
    "query": "original query",
    "has_grounding": true
  }
}
```

## Workflow

1. Check if GEMINI_API_KEY is set, prompt user if missing
2. Run the search script with user's query
3. Parse output (JSON format recommended for programmatic use)
4. Present response with sources to user

## Comparison with Other Search Tools

| Tool | Use Case |
|------|----------|
| **Gemini Search** | AI-synthesized answers with Google Search grounding |
| **Tavily** | Fast factual lookups, structured data extraction |
| **Perplexity** | Deep research, multi-step reasoning |
| **Web Search** | Direct web results without AI synthesis |

Use Gemini Search when the user specifically requests it or when you need Google's search index combined with Gemini's reasoning.
